﻿namespace Questao_2.API.Models
{
    public class FootballMatch
    {
        public string Team1 { get; set; }
        public string Team2 { get; set; }
        public int Team1Goals { get; set; }
        public int Team2Goals { get; set; }
    }
}
