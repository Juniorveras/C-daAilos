using Microsoft.AspNetCore.Mvc;
using Questao_2.API.Services;

namespace Questao_2.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    
    public class FootballGoalsController : ControllerBase
    {
        private readonly FootballMatchService _footballMatchService;

        public FootballGoalsController(FootballMatchService footballMatchService)
        {
            _footballMatchService = footballMatchService;
        }

        [HttpGet]
        public async Task<IActionResult> GetFootballGoalsAsync(int year)
        {
            var footballMatches = await _footballMatchService.GetFootballMatchesAsync(year);

            var teamGoals = footballMatches.GroupBy(m => m.Team1)
                .Select(g => new
                {
                    Team = g.Key,
                    Goals = g.Sum(m => m.Team1Goals) + g.Sum(m => m.Team2Goals)
                })
                .ToList();

            var results = teamGoals.Select(t => $"Team {t.Team} scored {t.Goals} goals in {year}");

            return Ok(results);
        }
    }
}
