﻿using Questao_2.API.Models;
using System.Text.Json;

namespace Questao_2.API.Services
{
    public class FootballMatchService
    {
        private readonly HttpClient _httpClient;

    public FootballMatchService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<List<FootballMatch>> GetFootballMatchesAsync(int year, string team1 = null, string team2 = null)
    {
        var url = $"https://jsonmock.hackerrank.com/api/football_matches?year={year}";
        if (!string.IsNullOrEmpty(team1))
        {
            url += $"&team1={team1}";
        }
        if (!string.IsNullOrEmpty(team2))
        {
            url += $"&team2={team2}";
        }

        var response = await _httpClient.GetAsync(url);
        response.EnsureSuccessStatusCode();
        
        var responseBody = await response.Content.ReadAsStringAsync();
        var footballMatches = JsonSerializer.Deserialize<List<FootballMatch>>(responseBody);

        return footballMatches;
    }
    }
}
