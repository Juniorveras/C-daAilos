﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao_2.Model
{
    internal class FootballModel
    {
        public class Test
        {
            public int Page { get; set; }
            public int PerPage { get; set; }
            public int Total { get; set; }
            public int TotalPages { get; set; }
            public List<Data> Data { get; set; }
        }
        public class Data
        {
            public string Team1 { get; set; }
            public string Team2 { get; set; }
            public string Team1Goals { get; set; }
            public string Team2Goals { get; set; }
        }
    }
}
