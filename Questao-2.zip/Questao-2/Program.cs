﻿// See https://aka.ms/new-console-template for more information
using Questao_2.Controller;
using Questao_2.View;

public class Program
{
    public static void Main(string[] args)
    {
        using (var reader = new StreamReader(Console.OpenStandardInput()))
        {
            FootballController controller = new FootballController();
            while (true)
            {
                Console.Write("Digite o nome do seu time: ");
                string team = Console.ReadLine();

                Console.Write("Digite o Ano: ");
                int year = int.Parse(Console.ReadLine());

                var result = controller.GetTotalGoals(team, year);
                Console.WriteLine(result);

                Console.Write("Deseja continuar? (Sim/Não): ");
                string response = Console.ReadLine();                
                if (response.ToLower() != "sim")
                {
                    break;
                }
            }
        }
    }
}
