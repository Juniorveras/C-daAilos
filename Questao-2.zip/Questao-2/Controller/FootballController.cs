﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Questao_2.Model.FootballModel;

namespace Questao_2.Controller
{
    public class FootballController
    {
        public string GetTotalGoals(string team, int year)
        {
            int pages = CallApi(team, year, 1, true, true);
            int goals = 0;
            for (int i = 1; i <= pages; i++)
            {
                goals = goals + CallApi(team, year, i, true, false) + CallApi(team, year, i, false, false);
            }
            return $"Team {team} scored {goals} goals in {year}";
        }

        private int CallApi(string team, int year, int page, bool isTeam1, bool isPageCount)
        {
            string urlAddress;
            if (isTeam1)
            {
                urlAddress = $"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team1={team}&page={page}";
            }
            else
            {
                urlAddress = $"https://jsonmock.hackerrank.com/api/football_matches?year={year}&team2={team}&page={page}";
            }

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                var response = client.GetAsync(urlAddress).Result;

                if (response.IsSuccessStatusCode)
                {
                    var responseContent = response.Content.ReadAsStringAsync().Result;
                    var test = JsonConvert.DeserializeObject<Test>(responseContent);

                    if (isPageCount)
                    {
                        return test.Total;
                    }
                    else
                    {
                        int goals = 0;
                        if (test.Data != null && test.Data.Count > 0)
                        {
                            foreach (var data in test.Data)
                            {
                                if (isTeam1 && team.Equals(data.Team1))
                                {
                                    goals += int.Parse(data.Team1Goals);
                                }
                                if (!isTeam1 && team.Equals(data.Team2))
                                {
                                    goals += int.Parse(data.Team2Goals);
                                }
                            }
                        }
                        return goals;
                    }
                }
                else
                {
                    throw new Exception($"Failed : HTTP error code : {response.StatusCode}");
                }
            }
        }
    }
}
