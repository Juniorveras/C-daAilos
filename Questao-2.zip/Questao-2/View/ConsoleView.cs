﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Questao_2.View
{
    public class ConsoleView
    {
        public void DisplayResult(int result)
        {
            Console.WriteLine(result);
        }
    }
}
